function Logout(){
    console.log("Logging out");
    localStorage.removeItem('ACCID');
    loadHomePage();
}

function loadHomePage(){
    window.location.href = '../../Home Page/index.html';
}