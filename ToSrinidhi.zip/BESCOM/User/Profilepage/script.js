document.addEventListener("DOMContentLoaded", function() {
    acc_id = localStorage.getItem("ACCID");
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    fetch('http://localhost:5000/user/getUserDetails', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({ ACCID:acc_id })
    })
    .then(response => response.json())
    .then(data=>tempfunc(data['data'][0]))
    .catch(error => console.error('Error:', error));
});

function tempfunc(data){
    console.log("Writing data");
    document.getElementById("accid").textContent = "Account ID: "+ data.ACC_ID;
    document.getElementById("name").textContent ="Name: "+ data.NAME;
    document.getElementById("addr").textContent = "Address:   "+ data.ADDRESS;
    document.getElementById("TID").textContent ="Tariff ID: "+ data.Tariff_ID;
    document.getElementById("SID").textContent = "Scheme ID:   "+ data.SCHEME_ID;
    document.getElementById("CStatus").textContent ="Connection Status: "+ 0;//data.C_STATUS;    
    document.getElementById("rcode").textContent = "Region Code:   "+ data.REGION_CODE;
    document.getElementById("Mread").textContent ="Previous Meter Reading: "+ data.PREV_READ;    

}

function Hello(){
    console.log("Hello");
    fetch('http://localhost:5000/user/test', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'GET'
//        body: JSON.stringify({ name: username, pass: password })
    })
    .then(response => console.log("tested"))
    .catch(error => console.error('Error:', error));

}
function Logout(){
    console.log("Logging out");
    localStorage.removeItem('ACCID');
    loadHomePage();
}

function loadHomePage(){
    window.location.href = '../../Home Page/index.html';
}