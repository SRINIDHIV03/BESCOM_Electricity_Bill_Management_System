//require("dotenv").config();
const dbService = require('./SQL_connect');
// const http = require('http');
// const url = require('url');
const express = require('express');
const express_session=require("express-session")
const cookie = require("cookie-parser");
const bodyparser = require('body-parser');
const cors = require('cors');


const app = express();
app.use(express.json());

//app.use(cookie);
app.use(express_session({
    secret: 'test',  // a secret string used to sign the session ID cookie
    resave: false,  // don't save session if unmodified
    saveUninitialized: false,  // don't create session until something stored
    cookie: {
        path: '/', // Ensure the cookie is accessible across paths
        // Other cookie options...
      }
  }));

app.use(cors());
app.use(bodyparser.json());

const PORT = 5000;

app.post('/genericQuery', (request, response) => {
    console.log("Update Data received");
    const { params } = request.body;
    const { query } = request.body;
//    const {condition} = request.body;
    const db = dbService.getDbServiceInstance();    
    const result = db.genericQuery(query,params);
    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});


app.post('/user/login',(req,res)=>{
    delete req.session.acc_id;
    const {ACCID} = req.body;
    console.log(ACCID);
//    req.session.user="Sup";
    req.session.acc_id=ACCID;
    console.log("Session: "+req.sessionID);
    res.status(200).json({ redirect: '../../User/Profile Page/index.html' });
    res.send("hello");
})

app.get("/user/test",(req,res)=>{
    console.log(req.session.user);
    console.log(req.session.acc_id);
    res.send("hurray");
});
app.get("/user/logout",(req,res)=>{
    delete req.session.user;
    delete req.session.acc_id;
//    console.log(req.session.user);
    res.send("hurray");
});
// app.get('/admin/login',(req,res)=>{
//     req.session.user="black clover";
//     res.send("hello");
// })
// app.get("/admin/test",(req,res)=>{
//     console.log(req.session.user);
//     res.send("hurray");
// });
// app.get("/admin/logout",(req,res)=>{
//     delete req.session.user;
//     console.log(req.session.user);
//     res.send("hurray");
// });


app.get('/getAll', (request, response) => {
    const db = dbService.getDbServiceInstance();

    const result = db.getAllData();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.get('/getBlankRegions', (request, response) => {
    const db = dbService.getDbServiceInstance();
    const result = db.getBlankRegions();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.post('/user/getUserDetails', (request, response) => {
    let {ACCID} = request.body;
    const db = dbService.getDbServiceInstance();
    
    const result = db.getUserDetails(ACCID);
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.get('/getAdminIDS', (request, response) => {
    const db = dbService.getDbServiceInstance();
    const result = db.getAdminIDs();    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.get('/getTariffs', (request, response) => {
    const db = dbService.getDbServiceInstance();

    const result = db.getTariffs();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.get('/getSchemes', (request, response) => {
    const db = dbService.getDbServiceInstance();

    const result = db.getSchemes();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.get('/getRegionDetails', (request, response) => {   //get all region details
    const db = dbService.getDbServiceInstance();

    const result = db.getRegionDetails();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.get('/getRegionNames', (request, response) => {   //get all region details
    const db = dbService.getDbServiceInstance();

    const result = db.getRegionNames();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});

app.get('/getSuperadminDetails', (request, response) => {   //get all region details
    const db = dbService.getDbServiceInstance();

    const result = db.getSuperadminDetails();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});


app.get('/getUserNameFromLogin', (request, response) => {
    const db = dbService.getDbServiceInstance();

    const result = db.getUserName_LoginData();
    
    result.then(console.log(result))
    .then(data => response.json({data : data}))    
    .catch(err => console.log(err));
});


app.post('/checkInUser', (request, response) => {
    console.log("User Input received");
 //   const { name } = request.body;
    const { pass } = request.body;
    const {ACCID} = request.body;
    const db = dbService.getDbServiceInstance();
    
    const result = db.isUserPresent(pass,ACCID);
    console.log("From experiment: "+result['truth']);
 //   request.session.user = ACCID;
    result
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});
app.post('/checkInAdmin', (request, response) => {
    console.log("User Input received");
 //   const { name } = request.body;
    const { pass } = request.body;
    const {ACCID} = request.body;
    const db = dbService.getDbServiceInstance();
    
    const result = db.isAdminPresent(pass,ACCID);
    console.log("From experiment: "+result['truth']);
 //   request.session.user = ACCID;
    result
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});
app.post('/checkInSuperAdmin', (request, response) => {
    console.log("User Input received");
 //   const { name } = request.body;
    const { pass } = request.body;
    const {ACCID} = request.body;
    const db = dbService.getDbServiceInstance();
    
    const result = db.isSuperAdminPresent(pass,ACCID);
    console.log("From experiment: "+result['truth']);
 //   request.session.user = ACCID;
    result
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});


app.post('/getTariffDetails', (request, response) => {
    console.log("User Input received");
    const { TID } = request.body;
    const db = dbService.getDbServiceInstance();
    
    const result = db.getTariff(TID);
//    const slabs = db.getTariffSlab(TID);
    console.log("From experiment: "+result);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});

app.post('/getSchemeDetails', (request, response) => {
    console.log("User Input received");
    const { SID } = request.body;
    const db = dbService.getDbServiceInstance();
    
    const result = db.getScheme(SID);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});

app.post('/getRegionAdminDetails', (request, response) => {
    console.log("User Input received");
    const { RNAME } = request.body;
    const db = dbService.getDbServiceInstance();
    
    const result = db.getRegionAdminDetails(RNAME);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});


app.post('/getAdminProfile', (request, response) => {
    console.log("Admin Input received");
    const { AID } = request.body;

    const db = dbService.getDbServiceInstance();    
    const result = db.getAdminProfile(AID);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});

app.post('/updateData', (request, response) => {
    console.log("Update Data received");
    const { param } = request.body;
    const { query } = request.body;
    const {condition} = request.body;

    const db = dbService.getDbServiceInstance();    
    const result = db.updateData(param,query,condition);
    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});
app.post('/insertScheme', (request, response) => {
    console.log("User Data received");
    const { SID } = request.body;
    const { percent_inc } = request.body;
    const { max_en } = request.body;

    const db = dbService.getDbServiceInstance();    
    const result = db.insertScheme(SID,percent_inc,max_en);
    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});
app.post('/insertAdmin', (request, response) => {
    console.log("User Data received");
    const { AID } = request.body;
    const { name } = request.body;
    const { phone } = request.body;
    const { rcode } = request.body;
    const { password } = request.body;
    console.log(rcode);

    const db = dbService.getDbServiceInstance();    
    const result = db.insertAdmin(AID,name,phone,rcode,password);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});
app.post('/insertUser', (request, response) => {
    console.log("User Data received");
    const { aadhar } = request.body;
    const { name } = request.body;
    const { phone } = request.body;
    const { rcode } = request.body;
    const { TID } = request.body;
    const { addr } = request.body;
    const {SID} = request.body;
    console.log(rcode);

    const db = dbService.getDbServiceInstance();    
    const result = db.insertUser(aadhar,name,addr,rcode,phone,TID,SID);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});

app.post('/deleteAdminId', (request, response) => {
    console.log("User Data received");
    const { AID } = request.body;

    const db = dbService.getDbServiceInstance();    
    const result = db.deleteAdminId(AID);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});
app.post('/deleteSchemeId', (request, response) => {
    console.log("Scheme ID received for deletion");
    const { SID } = request.body;

    const db = dbService.getDbServiceInstance();    
    const result = db.deleteSchemeId(SID);

    result    
    .then(data => response.json({ data: data}))
    .catch(err => console.log(err));
});



app.listen(PORT, () => console.log(`Hello World ${PORT}`));