document.addEventListener("DOMContentLoaded", function() {
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    fetch('http://localhost:5000/getSchemes', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'GET'
    })
    .then(response => response.json())
    .then(data=>tempfunc(data['data']))
    .catch(error => console.error('Error:', error));
});

function tempfunc(data){
    // Get the dropdown element
    console.log("In temp func");
    console.log(data);
    var deleteAdminDropdown = document.getElementById('dropdown');
deleteAdminDropdown.innerHTML = '';
data.forEach(function (adminId) {
console.log(adminId.SCHEME_ID);
var option = document.createElement('option');
option.value = adminId.SCHEME_ID;
option.text = adminId.SCHEME_ID;
deleteAdminDropdown.add(option);
});        
}


function deleteScheme(){
    console.log("Deleting...");
    var AID = document.getElementById("dropdown").value;
    console.log(AID);
    
    fetch('http://localhost:5000/deleteSchemeId', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({SID:AID}) //pass scheme id
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
};

function addScheme(){
    console.log("adding user");
        const SID = document.getElementById("schemeId").value;
        const max_en = document.getElementById("maxentitle").value;
        const percent_inc = document.getElementById("percentinc").value;
        
        // Display or use the values as needed
        console.log("SID: " +SID);
        console.log("max en: " +max_en);
        console.log("% inc: " + percent_inc);
        
        if (!/^[a-zA-Z0-9]+$/.test(SID)) {
            alert("Scheme ID should contain only alphanumeric characters");
            return;
        }
        if( Number.isFinite(percent_inc) && (percent_inc<=0 || percent_inc>10)){
            alert("Percent increase has to lie between 0 and 10");
            return;        
        }
        // if (!/^[a-zA-Z\s]+$/.test(name)) {
        //     alert("Name must contain only alphabetic characters");
        //     return;
        // }
        if (!/^\d+$/.test(max_en)) {
            alert("Max entitlement is a number");
            return;
        }
        fetch('http://localhost:5000/insertScheme', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({ SID:SID,max_en:max_en,percent_inc:percent_inc})
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
    }

