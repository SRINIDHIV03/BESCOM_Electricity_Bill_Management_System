var len=0;

document.addEventListener("DOMContentLoaded", function() {
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    fetch('http://localhost:5000/getTariffs', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'GET'
    })
    .then(response => response.json())
    .then(data=>tempfunc(data['data']))
    .catch(error => console.error('Error:', error));
});
function tempfunc(data){
        // Get the dropdown element
        var dropdown = document.getElementById("tariffCode");
        dropdown.innerHTML = ""; //clear existing

        data.forEach(function(option) {
            var newOption = document.createElement("option");
            newOption.value = option.Tariff_id;
            newOption.text = option.Tariff_id;
            dropdown.add(newOption);
        });   
        loadTable();
    }

function handleDropdownChange(dropdown) {
        var selectedValue = dropdown.value;
        console.log("Selected value:", selectedValue);
        loadTable();
        // Perform actions based on the selected value
        // Add your code here
    }
function loadTable(){
    var TID = document.getElementById("tariffCode").value;
    console.log("Loading:"+TID);
    fetch('http://localhost:5000/getTariffDetails', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({TID:TID})
    })
    .then(response => response.json())
    .then(data=>fillTable(data['data']))
    .catch(error => console.error('Error:', error));
}
function fillTable(tariff){
    console.log(tariff);
    data = tariff.slabs;
    console.log(data);
    var table = document.getElementById('chargeTable').getElementsByTagName('tbody')[0];
    while (table.firstChild) {
        table.removeChild(table.firstChild);
      }

    data.forEach(function(obj){

    var newRow = table.insertRow(table.rows.length);
    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);
    var cell3 = newRow.insertCell(2);
    var cell4 = newRow.insertCell(3);

    cell1.innerHTML = obj.low;
    cell2.innerHTML = obj.up;
    cell3.innerHTML = obj.slabs;
    cell4.innerHTML = '<button onclick="modifyCharge(event)">Modify</button>';
    });
}

function updateTariff(index){
    console.log(x);    
    var AID = document.getElementById("tariffCode").value;
    console.log(AID);
    var x;
    var query;
    if(index==0){
        x = document.getElementById("tariffName3").value;
        if(!/^[a-zA-Z\s]+$/.test(x)){
            alert("Name must have only letters");
            return;
        }
        query ="UPDATE TARIFF SET TARIFF_NAME=? WHERE TARIFF_ID=?;";
    }
    else if(index==1){
        x = parseFloat(document.getElementById("tariffrate3").value);
        if(isNaN(x)){
            alert("Default rate must be a float value");
            return;
        }
        query ="UPDATE TARIFF SET default_rate=? WHERE TARIFF_ID=?;";
    }
    else if(index==2){
        x = parseFloat(document.getElementById("tarifffppca3").value);
        if(isNaN(x)){
            alert("FPPCA must be a float value");
            return;
        }
        query ="UPDATE TARIFF SET fppca=? WHERE TARIFF_ID=?;";
    }
    else {
        x = parseFloat(document.getElementById("tariffenergy3").value);
        if(isNaN(x)){
            alert("Energy Rate must be a float value");
            return;
        }
        query ="UPDATE TARIFF SET energy=? WHERE TARIFF_ID=?;";
    }
    fetch('http://localhost:5000/updateData', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query,condition:AID, param:x})
    })
    .then(response => function(){
        alert("Updated");
        setTimeout(function() {
            location.reload();
          }, 3000);    
    })
    .catch(error => console.error('Error:', error));
};



function addRow() {    

    var table = document.getElementById('chargeTable').getElementsByTagName('tbody')[0];
    console.log(table.rows.length);

    var upperLimit = parseFloat(document.getElementById('upperLimit').value);
    var charge = parseFloat(document.getElementById('charge').value);
    console.log(upperLimit);
    console.log(charge);
    if(isNaN(upperLimit)){
        alert("Upper Limit must be a number");
        return;
    }
    if(isNaN(charge)){
        alert("Charge must be a number");
        return;
    }    
    var lowerLimit = (table.rows.length==0) ? 0: table.rows[table.rows.length-1].cells[1].innerHTML ;
    
    console.log(lowerLimit);
    console.log(upperLimit);
    if(lowerLimit>=upperLimit){   //previous row upper limit MUST BE lower limit of next row
        alert('Upper limit must be larger than previous upper limit');
        return;
    }
    // var table = document.getElementById('chargeTable').getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.rows.length);

    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);
    var cell3 = newRow.insertCell(2);
    var cell4 = newRow.insertCell(3);

    cell1.innerHTML = lowerLimit;
    cell2.innerHTML = upperLimit;
    cell3.innerHTML = charge;
    cell4.innerHTML = '<button onclick="modifyCharge(event)">Modify</button>';
    //len++;
    var TID = document.getElementById("tariffCode").value;

    query = "INSERT INTO Tariff_slab(tariff_id,low,up,charge) VALUES(?,?,?,?);"
    params = [TID,lowerLimit,upperLimit,charge];
    fetch('http://localhost:5000/genericQuery', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query, params:params})
    })
    .then(response => console.log("success"))
    .catch(error => console.error('Error:', error)); 
}

function deleteBottomRow() {
    var table = document.getElementById('chargeTable').getElementsByTagName('tbody')[0];
    var lastRowIndex = table.rows.length-1;
    var Limit;
    if(table.rows.length==0){
        return;
    }
    else{
        Limit = table.rows[table.rows.length-1].cells[1].innerHTML;
    }
    console.log(Limit);
    if (lastRowIndex >= 0) {
        table.deleteRow(lastRowIndex);
    //    len--;
    }        
    var TID = document.getElementById("tariffCode").value;

    query = "DELETE FROM Tariff_slab WHERE Tariff_id=? AND up=?;"
    params = [TID,Limit];
    fetch('http://localhost:5000/genericQuery', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query, params:params})
    })
    .then(response => console.log("deleted slab"))
    .catch(error => console.error('Error:', error)); 
}


function modifyCharge(event) {
    event.preventDefault();
    var button = event.target;
    var row = button.parentNode.parentNode;
    console.log(row.cells[0].innerHTML);
    console.log(row.cells[2].innerHTML);
    var low = row.cells[0].innerHTML;
    var TID = document.getElementById("tariffCode").value;
    var charge = prompt('Enter the new charge:');
    row.cells[2].innerHTML = charge;
    query = "UPDATE Tariff_Slab SET charge=? WHERE tariff_id=? AND low=?;"
   fetch('http://localhost:5000/genericQuery', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query, params:[charge,TID,low]})
    })
    .then(response => function(){
        alert("Updated");
        setTimeout(function() {
            location.reload();
        }, 3000);    
    })
    .catch(error => console.error('Error:', error));
}

function deleteTariff(){
    var TID = document.getElementById("tariffCode").value;
    console.log("Deleting: "+TID);
    var TID = document.getElementById("tariffCode").value;

    query = "DELETE FROM Tariff WHERE Tariff_id=?;"
    params = [TID];
    fetch('http://localhost:5000/genericQuery', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query, params:params})
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error)); 
}

function addTariff(){
    var TID = document.getElementById("tariffId").value;
    if (!/^[a-zA-Z0-9]+$/.test(TID)) {
        alert("Tariff ID should contain only alphanumeric characters");
        return;
    }
    var Tname = document.getElementById("tariffName").value;
    if (!/^[a-zA-Z\s]+$/.test(Tname)) {
        alert("Tariff name must contain only alphabetic characters");
        return;
    }
    var def = document.getElementById("defRate").value;
    if(isNaN(def)){
        alert("Default Rate must be a number");
        return;
    }
    var fppca = document.getElementById("fppca").value;
    if(isNaN(fppca)){
        alert("FPPCA must be a number");
        return;
    }
    var energy = document.getElementById("energy").value;
    if(isNaN(energy)){
        alert("Energy charge must be a number");
        return;
    }
    
    query = "INSERT INTO Tariff VALUES (?,?,?,?,?);"
    params = [TID,Tname,def,fppca,energy];
    fetch('http://localhost:5000/genericQuery', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query, params:params})
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error)); 
}