document.addEventListener("DOMContentLoaded", function() {
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    fetch('http://localhost:5000/getRegionDetails', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'GET'
    })
    .then(response => response.json())
    .then(data=>tempfunc(data['data']))
    .catch(error => console.error('Error:', error));
});

function tempfunc(data){
    // Get the dropdown element
    console.log("In temp func");
    console.log(data);
    var deleteAdminDropdown = document.getElementById('dropdown');
deleteAdminDropdown.innerHTML = '';
data.forEach(function (adminId) {
console.log(adminId.REGION_CODE);
var option = document.createElement('option');
option.value = adminId.REGION_CODE;
option.text = adminId.REGION_CODE;
deleteAdminDropdown.add(option);
});        

// var myButton = document.getElementById("adminbutton");
// myButton.disabled = true;
// myButton = document.getElementById("passbutton");
// myButton.disabled = true;
// myButton = document.getElementById("regionbutton");
// myButton.disabled = true;
// myButton = document.getElementById("phonebutton");
// myButton.disabled = true;
}

// document.addEventListener("DOMContentLoaded", function() {
//     //var username = document.getElementById("username").value;
//     //var password = document.getElementById("password").value;
//     fetch('http://localhost:5000/getBlankRegions', {
//         headers: {
//             'Content-type': 'application/json'
//         },
//         method: 'GET'
//     })
//     .then(response => response.json())
//     .then(data=>tempfunc_region(data['data']))
//     .catch(error => console.error('Error:', error));
// });

// function tempfunc_region(data){
//     // Get the dropdown element
//     console.log("In temp func region");
//     console.log(data);
// var deleteAdminDropdown = document.getElementById('regionCode');

// deleteAdminDropdown.innerHTML = '';
// data.forEach(function (adminId) {
// console.log(adminId.Username);
// var option = document.createElement('option');
// option.value = adminId.REGION_CODE;
// option.text = adminId.REGION_CODE;
// deleteAdminDropdown.add(option);
// });        

// var deleteAdminDropdown = document.getElementById('regionCode3');

// deleteAdminDropdown.innerHTML = '';
// data.forEach(function (adminId) {
// console.log(adminId.Username);
// var option = document.createElement('option');
// option.value = adminId.REGION_CODE;
// option.text = adminId.REGION_CODE;
// deleteAdminDropdown.add(option);
// });
// }

function deleteAdmin(){
    console.log("Deleting...");
    var AID = document.getElementById("dropdown").value;
    console.log(AID);
    
    query = "DELETE FROM REGION WHERE REGION_CODE=?;";
    params = [AID];

    fetch('http://localhost:5000/genericQuery', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query,params:params})
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
};

// function toggleAdmin(){
//     var myButton = document.getElementById("adminbutton");
//     myButton.disabled = !myButton.disabled;
//     myButton = document.getElementById("passbutton");
//     myButton.disabled = !myButton.disabled;
//     myButton = document.getElementById("regionbutton");
//     myButton.disabled = !myButton.disabled;
//     myButton = document.getElementById("phonebutton");
//     myButton.disabled = !myButton.disabled;
// }

function updateAdmin(index){
    console.log("Updating...");
    var AID = document.getElementById("adminId3").value;
    console.log(AID);
    var x;
    var query;
    if(index==0){
        x = document.getElementById("adminName3").value;
        query ="UPDATE REGION SET REGION_NAME=? WHERE REGION_CODE=?;";
    }
    else if(index==1){
        x = document.getElementById("adminPass3").value;
        query ="UPDATE REGION SET OFFICE_LOC=? WHERE REGION_CODE=?;";
    }

    fetch('http://localhost:5000/updateData', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query,condition:AID, param:x})
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
};


function addAdmin(){
    console.log("adding user");
        const AID = document.getElementById("adminId2").value;
        const name = document.getElementById("adminName2").value;
        const password = document.getElementById("adminPass").value;

        // Display or use the values as needed
        console.log("RCode: " + AID);
        console.log("Rame: " + name);
        console.log("Office Loc: " + password);
        
        if (!/^[a-zA-Z0-9]+$/.test(AID)) {
            alert("Admin ID should contain only alphanumeric characters");
            return;
        }
        if (!/^[a-zA-Z\s]+$/.test(name)) {
            alert("Name must contain only alphabetic characters");
            return;
        }
        query = "INSERT INTO REGION VALUES (?,?,?);";
        params = [AID,name,password];
        
        fetch('http://localhost:5000/genericQuery', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({ query:query,params:params })
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
    }

