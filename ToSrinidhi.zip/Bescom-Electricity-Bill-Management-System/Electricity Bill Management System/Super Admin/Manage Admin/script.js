document.addEventListener("DOMContentLoaded", function() {
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    fetch('http://localhost:5000/getAdminIDs', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'GET'
    })
    .then(response => response.json())
    .then(data=>tempfunc(data['data']))
    .catch(error => console.error('Error:', error));
});

function tempfunc(data){
    // Get the dropdown element
    console.log("In temp func");
    console.log(data);
    var deleteAdminDropdown = document.getElementById('dropdown');
deleteAdminDropdown.innerHTML = '';
data.forEach(function (adminId) {
console.log(adminId.Username);
var option = document.createElement('option');
option.value = adminId.Username;
option.text = adminId.Username;
deleteAdminDropdown.add(option);
});        

var myButton = document.getElementById("adminbutton");
myButton.disabled = true;
myButton = document.getElementById("passbutton");
myButton.disabled = true;
myButton = document.getElementById("regionbutton");
myButton.disabled = true;
myButton = document.getElementById("phonebutton");
myButton.disabled = true;
}

document.addEventListener("DOMContentLoaded", function() {
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    fetch('http://localhost:5000/getBlankRegions', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'GET'
    })
    .then(response => response.json())
    .then(data=>tempfunc_region(data['data']))
    .catch(error => console.error('Error:', error));
});

function tempfunc_region(data){
    // Get the dropdown element
    console.log("In temp func region");
    console.log(data);
var deleteAdminDropdown = document.getElementById('regionCode');

deleteAdminDropdown.innerHTML = '';
data.forEach(function (adminId) {
console.log(adminId.Username);
var option = document.createElement('option');
option.value = adminId.REGION_CODE;
option.text = adminId.REGION_CODE;
deleteAdminDropdown.add(option);
});        

var deleteAdminDropdown = document.getElementById('regionCode3');

deleteAdminDropdown.innerHTML = '';
data.forEach(function (adminId) {
console.log(adminId.Username);
var option = document.createElement('option');
option.value = adminId.REGION_CODE;
option.text = adminId.REGION_CODE;
deleteAdminDropdown.add(option);
});
}

function deleteAdmin(){
    console.log("Deleting...");
    var AID = document.getElementById("dropdown").value;
    console.log(AID);
    
    fetch('http://localhost:5000/deleteAdminId', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({AID:AID})
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
};

function toggleAdmin(){
    var myButton = document.getElementById("adminbutton");
    myButton.disabled = !myButton.disabled;
    myButton = document.getElementById("passbutton");
    myButton.disabled = !myButton.disabled;
    myButton = document.getElementById("regionbutton");
    myButton.disabled = !myButton.disabled;
    myButton = document.getElementById("phonebutton");
    myButton.disabled = !myButton.disabled;
}

function updateAdmin(index){
    console.log("Updating...");
    var AID = document.getElementById("adminId3").value;
    console.log(AID);
    var x;
    var query;
    if(index==0){
        x = document.getElementById("adminName3").value;
        query ="UPDATE ADMINISTRATOR SET NAME=? WHERE ADMIN_ID=?;";
    }
    else if(index==1){
        x = document.getElementById("adminPass3").value;
        query ="UPDATE ADMIN_LOGINS SET Password=? WHERE Username=?;";
    }
    else if(index==2){
        x = document.getElementById("adminPhone3").value;
        query ="UPDATE ADMINISTRATOR SET PHONE=? WHERE ADMIN_ID=?;";
    }
    else {
        x = document.getElementById("regionCode3").value;
        query ="UPDATE ADMINISTRATOR SET REGION_CODE=? WHERE ADMIN_ID=?;";
    }
    fetch('http://localhost:5000/updateData', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query:query,condition:AID, param:x})
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
};


function addAdmin(){
    console.log("adding user");
        const AID = document.getElementById("adminId2").value;
        const name = document.getElementById("adminName2").value;
        const password = document.getElementById("adminPass").value;
        const phone = document.getElementById("adminPhone2").value;
        const rcode = document.getElementById("regionCode").value;

        // Display or use the values as needed
        console.log("AID: " + AID);
        console.log("Name: " + name);
        console.log("Password: " + password);
        console.log("Phone: " + phone);
        console.log("Region Code:"+rcode);
        
        var inputs = document.querySelectorAll('#addAdminForm input');
        var inputBlocks = [];
      
        inputs.forEach(function(input) {
          var inputBlock = {
            label: input.previousElementSibling.innerText,
            input: input
          };      
          inputBlocks.push(inputBlock);
        });
        console.log(inputBlocks);

        if (!/^[a-zA-Z0-9]+$/.test(AID)) {
            alert("Admin ID should contain only alphanumeric characters");
            return;
        }
        if (!/^[a-zA-Z\s]+$/.test(name)) {
            alert("Name must contain only alphabetic characters");
            return;
        }
        if (!/^\d+$/.test(phone)) {
            alert("Phone must contain only numbers");
            return;
        }
        fetch('http://localhost:5000/insertAdmin', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({ AID:AID,name:name,phone:phone,password:password,rcode:rcode })
    })
    .then(response => location.reload())
    .catch(error => console.error('Error:', error));
    }

