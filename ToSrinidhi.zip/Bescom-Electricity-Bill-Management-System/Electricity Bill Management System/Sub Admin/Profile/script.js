var pagetitle = document.getElementById("pagetitle");
if (pagetitle) {
  pagetitle.addEventListener("click", function (e) {
    // Please sync "generate bill" to the project
  });
}

var pagetitle1 = document.getElementById("pagetitle1");
if (pagetitle1) {
  pagetitle1.addEventListener("click", function (e) {
    window.location.href = "./Profile1.html";
  });
}

var pagetitle2 = document.getElementById("pagetitle2");
if (pagetitle2) {
  pagetitle2.addEventListener("click", function (e) {
    // Please sync "User" to the project
  });
}

var pagetitle3 = document.getElementById("pagetitle3");
if (pagetitle3) {
  pagetitle3.addEventListener("click", function (e) {
    window.location.href = "./Dashboard.html";
  });
}
var scrollAnimElements = document.querySelectorAll("[data-animate-on-scroll]");
var observer = new IntersectionObserver(
  (entries) => {
    for (const entry of entries) {
      if (entry.isIntersecting || entry.intersectionRatio > 0) {
        const targetElement = entry.target;
        targetElement.classList.add("animate");
        observer.unobserve(targetElement);
      }
    }
  },
  {
    threshold: 0.15,
  }
);

for (let i = 0; i < scrollAnimElements.length; i++) {
  observer.observe(scrollAnimElements[i]);
}

function Logout(){
    console.log("Logging out");
    localStorage.removeItem('Admin_ID');
    localStorage.removeItem('RCODE');
    localStorage.removeItem('RNAME');

    // localStorage.clear();
    window.location.href="../../../../BESCOM/Home Page/index.html"
}

document.addEventListener("DOMContentLoaded", function() {
    acc_id = localStorage.getItem("Admin_ID");
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    fetch('http://localhost:5000/getAdminProfile', {
        headers: {
            'Content-type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({ AID:acc_id })
    })
    .then(response => response.json())
    .then(data=>tempfunc(data['data'][0]))
    .catch(error => console.error('Error:', error));
});

function tempfunc(data){
    console.log("Writing data");
    console.log(data);
    document.getElementById("adminid").textContent = data.ADMIN_ID;
    document.getElementById("name").textContent = data.NAME;
    document.getElementById("address").textContent = data.OFFICE_LOC;
    document.getElementById("phone").textContent =data.PHONE;
    document.getElementById("rname").textContent =data.REGION_NAME;
    localStorage.setItem("RNAME", data.REGION_NAME);
    localStorage.setItem("RCODE", data.REGION_CODE);
}
